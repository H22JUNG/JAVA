package com.goodee.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.goodee.dao.BookDAO;
import com.goodee.service.BookService;
import com.goodee.vo.BookVO;

public class BookView {
	BookService service = new BookService();
	
	public void rantalBookView(Scanner scan) {
		service.getMenu();
		
		List<BookVO> list = service.getMenu();
		for(int i=0; i<list.size(); i++){
			System.out.println(list.get(i));
		};
		System.out.println();
		
		System.out.println("어떤 책을 대여하시겠습니까? (없는 숫자를 누를 경우 본 메뉴로 돌아갑니다.)");
		int id = scan.nextInt();
		scan.nextLine();
		
		
		System.out.println("----------------결과----------------");
		BookVO vo = new BookVO();
		BookDAO dao = new BookDAO();
		vo.setId(id);
		if(dao.selectListBook().get(id-1).getRantalNum() >= 1)
		vo.setRantalNum(dao.selectListBook().get(id-1).getRantalNum()-1);
		else
		vo.setRantalNum(dao.selectListBook().get(id-1).getRantalNum());
		
		dao.updateBookItem(vo);
		System.out.println(service.setRantal(vo));
	}
	
	public void returnBookView(Scanner scan) {
		service.getMenu();
		
		List<BookVO> list = service.getMenu();
		for(int i=0; i<list.size(); i++){
			System.out.println(list.get(i));
		};
		
		System.out.println();
		System.out.println("어떤 책을 반납하시겠습니까? (없는 숫자를 누를 경우 본 메뉴로 돌아갑니다.)");
		int id = scan.nextInt();
		scan.nextLine();
		
		System.out.println("----------------결과----------------");
		BookVO vo = new BookVO();
		vo.setId(id);
		BookDAO dao = new BookDAO();
		vo.setRantalNum(dao.selectListBook().get(id-1).getRantalNum()+1);
		dao.updateBookItem(vo);
		System.out.println(service.setReturn(vo));
		
		
		
		
		
		
	}
	
	public void addBookView(Scanner scan) {
		BookVO vo = new BookVO();
		System.out.println("책 제목은 무엇입니까?");
		vo.setBname(scan.nextLine());
		System.out.println("작가는 누구입니까?");
		vo.setAuthor(scan.nextLine());
		System.out.println("출판일은 언제입니까? (YYYY-MM-DD");
		vo.setCreateDate(scan.nextLine());
		System.out.println("재고는 몇개입니까?");
		vo.setStock(scan.nextInt());
		scan.nextLine();
		
		System.out.println("----------------결과----------------");
		System.out.println(service.setBook(vo));
		service.getMenu();
	}
	
	public void removeBookView(Scanner scan) {
		service.getMenu();
		
		List<BookVO> list = service.getMenu();
		for(int i=0; i<list.size(); i++){
			System.out.println(list.get(i));
		};
		
		System.out.println();
		System.out.println("어떤 책을 삭제하시겠습니까? (없는 숫자를 누를 경우 본 메뉴로 돌아갑니다.)");
		int id = scan.nextInt();
		scan.nextLine();
		
		
		System.out.println("----------------결과----------------");
		BookVO vo = new BookVO();
		vo.setId(id);
		System.out.println(service.removeBook(vo));
		service.getMenu();
	}
}
