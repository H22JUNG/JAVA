package com.goodee.service;

import java.util.List;

import com.goodee.dao.BookDAO;
import com.goodee.view.BookView;
import com.goodee.vo.BookVO;

public class BookService {
	BookDAO dao = new BookDAO();
	
	public List<BookVO> getMenu() {
		return dao.selectListBook();
	}
	
	public String setRantal(BookVO vo) {
		if(vo.getRantalNum() == 0) {
			return "더 이상 빌릴 책이 없습니다.";
		}else {
			dao.updateBookItem(vo);
			if(dao.updateBookItem(vo)==true) { return "대여에 성공하였습니다.";
			} else { return "대여에 실패하였습니다";
		}
	}
	}
	
	
	public String setReturn(BookVO vo) {
			if(vo.getRantalNum() >= vo.getStock()) {
				return "더 이상 반납할 책이 없습니다.";
			} else {
				dao.updateBookItem(vo);
				if(dao.updateBookItem(vo)==true) { return "반납에 성공하였습니다.";
				} else { return "반납에 실패하였습니다";
		}
	}
	}
	
	public String setBook(BookVO vo) {
		if(dao.insertBookItem(vo)==true) {
		return "추가에 성공하였습니다";
		} else {return "추가하지 못했습니다";}
	}
	
	
	public String removeBook(BookVO vo) {
		if(dao.deleteBookItem(vo)==true) {
			return "제거에 성공하였습니다";
		} else {
		return "제거에 실패하였습니다";
		}
	}
	
}
