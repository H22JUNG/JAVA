package com.goodee.main;

import java.util.Scanner;

import com.goodee.view.BookView;

public class BookStoreMain {
	private Scanner scan = new Scanner(System.in);
	
	public BookStoreMain() {
		boolean flag = true;
		BookView view = new BookView();
		
		while(flag) {
			getIntro();
			
			int i = scan.nextInt();
			scan.nextLine();
			if(i==1) {
				view.rantalBookView(scan);
			}else if(i==2) {
				view.returnBookView(scan);
			}else if(i==3) {
				view.addBookView(scan);
			}else if(i==4) {
				view.removeBookView(scan);
			}else {
				flag = false;
				System.out.println("도서 대여 관리 프로그램을 종료합니다.");
			}
			
		}
	}
	
	
	public void getIntro() {
		System.out.println();
		System.out.println();
		System.out.println("-- 도서 대여 관리 프로그램--");
		System.out.println("1. 도서 대여");
		System.out.println("2. 도서 반납");
		System.out.println("3. 도서 추가");
		System.out.println("4. 도서 삭제");
		System.out.println("etc. 종료");
	}
	
	public static void main(String[] args) {
		new BookStoreMain();
	}
	
}
