package com.goodee.vo;

public class BookVO {
	private int id;
	private String bname;
	private String author;
	private String createDate;
	private int stock;
	private int rantalNum;

	public BookVO() {
		// TODO Auto-generated constructor stub
	}

	public BookVO(int id, String bname, String author, String createDate, int stock, int rantalNum) {
		this.id = id;
		this.bname = bname;
		this.author = author;
		this.createDate = createDate;
		this.stock = stock;
		this.rantalNum = rantalNum;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public int getRantalNum() {
		return rantalNum;
	}

	public void setRantalNum(int rantalNum) {
		this.rantalNum = rantalNum;
	}

	@Override
	public String toString() {
		return id + ". [도서명=" + bname + ", 작가=" + author + ", 출판일=" + createDate
				+ ", 재고=" + stock + ", 대여가능수=" + rantalNum + "]";
	}
	
	
	
}
