package com.goodee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.goodee.conn.JDBCConnection;
import com.goodee.view.BookView;
import com.goodee.vo.BookVO;

public class BookDAO {
	public List<BookVO> selectListBook() {
		ArrayList<BookVO> list = new ArrayList<BookVO>();
		Connection conn = JDBCConnection.getConn();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			String sql = "select id, bname, author, create_date, stock, rantal_num from books";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				BookVO vo = new BookVO();
				vo.setId(rs.getInt(1));
				vo.setBname(rs.getString(2));
				vo.setAuthor(rs.getString(3));
				vo.setCreateDate(rs.getString(4));
				vo.setStock(rs.getInt(5));
				vo.setRantalNum(rs.getInt(6));
				list.add(vo);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return list;
	}
	
	public boolean updateBookItem(BookVO vo) {
		Connection conn = JDBCConnection.getConn();
		PreparedStatement pstmt = null;
		int i = 0;
		
		try {
			String sql = "update books set rantal_num = ? where id = ? ";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, vo.getRantalNum());
			pstmt.setInt(2, vo.getId());
			
			i = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return (i>0) ? true : false;
	}
	
	
	
	public boolean insertBookItem(BookVO vo) {
		Connection conn = JDBCConnection.getConn();
		PreparedStatement pstmt = null;
		int i = 0;
		
		try {
			String sql = "insert into books(bname, author, create_date, stock, rantal_num)"
					+ " values(?,?,STR_TO_DATE(?,'%Y-%m-%d'),?,?)";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, vo.getBname());
			pstmt.setString(2, vo.getAuthor());
			pstmt.setString(3, vo.getCreateDate());
			pstmt.setInt(4, vo.getStock());
			pstmt.setInt(5, vo.getStock());
			
			i = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return (i>0)? true : false ;
	}
	
	public boolean deleteBookItem(BookVO vo) {
		Connection conn = JDBCConnection.getConn();
		PreparedStatement pstmt = null;
		int i = 0;
		
		try {
			String sql = "delete from books where id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, vo.getId());
			
			
			i = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return (i>0)? true : false ;
	}
}
